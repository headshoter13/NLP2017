import re


def abbreviations(file, reg_exp, nameOfFile):
    text = open(file, 'r', encoding = 'utf-8').read()
    outfile = open(nameOfFile, 'w', encoding = 'utf-8-sig')
    shorts = re.findall(reg_exp, text)
    print(shorts)
    for i in shorts:
        outfile.write(i + '\r\n')
    outfile.close()





abbreviations('text.txt', '(\w+\. ?)[а-я]+','list of abbreviations.txt')
abbreviations('text.txt', '[А-Я][а-я]+ ([А-Я]\.[А-Я]\.)', 'initials.txt')
